# Calendario de contenido — ApuntesIA (30 artículos, 1/semana ≈ 7 meses)

Cada título ya está pensado como palabra clave de búsqueda. Escribe uno por semana siguiendo la estructura del artículo de ejemplo (intro → H2 → H2 con lista → precio/límites → H2 conclusión → FAQ → anuncios cada 2-3 bloques).

## Comparativas (más fáciles de rankear, intención clara)
1. Notion AI vs ChatGPT para tomar apuntes (✅ ya escrito)
2. Otter.ai vs Notion AI para transcribir clases grabadas
3. Grammarly vs ChatGPT para corregir trabajos en español
4. Quillbot vs ChatGPT para parafrasear textos académicos
5. Google Gemini vs ChatGPT: ¿cuál es mejor para estudiar?
6. Anki vs apps de IA para hacer flashcards de repaso

## Guías prácticas (resuelven un problema concreto)
7. Cómo resumir un PDF largo con IA sin perder información importante
8. Cómo usar ChatGPT para hacer un esquema de un tema en 5 minutos
9. Cómo transcribir una clase grabada y convertirla en apuntes limpios
10. Cómo crear preguntas de repaso con IA a partir de tus apuntes
11. Cómo organizar el temario de una asignatura con Notion e IA
12. Cómo usar la IA para estudiar sin que te resuelva los ejercicios por ti
13. Cómo preparar un examen tipo test con ayuda de IA
14. Cómo hacer un cronograma de estudio con IA para exámenes finales
15. Cómo pasar apuntes a mano a digital usando IA (OCR + resumen)

## Herramientas específicas (long-tail, poca competencia)
16. Las mejores apps de IA gratuitas para estudiantes en 2026
17. Mejores extensiones de Chrome con IA para estudiar
18. Apps de IA para aprender idiomas mientras estudias otra carrera
19. Herramientas de IA para hacer mapas mentales automáticamente
20. Apps de IA para practicar exposiciones orales antes de un examen
21. Herramientas de IA para citar bibliografía en formato APA/Vancouver

## Casos de uso por carrera (diferenciación, baja competencia)
22. Mejores apps de IA para estudiantes de Medicina
23. Mejores apps de IA para estudiantes de Derecho
24. Mejores apps de IA para estudiantes de ingeniería (fórmulas y cálculo)
25. Mejores apps de IA para estudiantes de idiomas

## Dudas y límites (contenido de confianza, engagement alto)
26. ¿Es trampa usar ChatGPT para hacer trabajos? Dónde está el límite
27. Cómo saber si un profesor puede detectar que usaste IA en un trabajo
28. Riesgos de depender demasiado de la IA para estudiar
29. Cómo citar que has usado IA en un trabajo académico
30. Qué datos tuyos guardan estas apps de IA (privacidad para estudiantes)

---
**Ritmo recomendado:** 1 artículo/semana, ~2-2.5h (investigar + escribir + maquetar en HTML + publicar). Con las 30 ideas ya no tienes que pensar "qué escribo esta semana", solo ejecutar.
